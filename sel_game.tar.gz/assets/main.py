import pygame
import sys
import asyncio

pygame.init()

BOARD_SIZE = 480
HUD_HEIGHT = 80
WIDTH = 480
HEIGHT = BOARD_SIZE + HUD_HEIGHT

ROWS, COLS = 8, 8
SQ_SIZE = BOARD_SIZE // COLS

LIGHT_SQ = (235, 236, 208)
DARK_SQ = (119, 149, 86)
HIGHLIGHT = (245, 230, 90)
TARGET_TILE_W = (180, 220, 240)
TARGET_TILE_B = (240, 190, 190)

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Race the King Home")

# Universal mobile-safe fonts
font_piece = pygame.font.SysFont("dejavusans,freesansbold,arial", 22, bold=True)
font_hud = pygame.font.SysFont("arial,sans-serif", 16, bold=True)
font_win = pygame.font.SysFont("arial,sans-serif", 24, bold=True)

# Clean, universal piece labels that work on all phones
PIECE_LABELS = {
    "K": "KING", "Q": "QUEEN", "R": "ROOK", "B": "BISHOP", "N": "KNIGHT", "P": "PAWN",
    "k": "king", "q": "queen", "r": "rook", "b": "bishop", "n": "knight", "p": "pawn",
}

# The jammed initial board
board = [
    [".", ".", ".", ".", ".", ".", ".", "."],  # Row 0, Col 4 is Black King's Goal
    [".", "r", "n", "b", "q", "b", "n", "r"],
    [".", "p", "p", "p", "p", "p", "p", "."],
    [".", ".", ".", ".", "k", ".", ".", "."],  # Black King
    [".", ".", ".", ".", "K", ".", ".", "."],  # White King
    [".", "P", "P", "P", "P", "P", "P", "."],
    [".", "R", "N", "B", "Q", "B", "N", "R"],
    [".", ".", ".", ".", ".", ".", ".", "."],  # Row 7, Col 4 is White King's Goal
]

current_turn = "W"
selected_square = None
winner = None

def draw_board():
    for r in range(ROWS):
        for c in range(COLS):
            rect = pygame.Rect(c * SQ_SIZE, r * SQ_SIZE, SQ_SIZE, SQ_SIZE)
            if (r, c) == (0, 4):
                color = TARGET_TILE_B
            elif (r, c) == (7, 4):
                color = TARGET_TILE_W
            else:
                color = LIGHT_SQ if (r + c) % 2 == 0 else DARK_SQ
            
            pygame.draw.rect(screen, color, rect)
            if selected_square == (r, c):
                pygame.draw.rect(screen, HIGHLIGHT, rect)

def draw_pieces():
    for r in range(ROWS):
        for c in range(COLS):
            p = board[r][c]
            if p != ".":
                cx = c * SQ_SIZE + SQ_SIZE // 2
                cy = r * SQ_SIZE + SQ_SIZE // 2
                is_w = p.isupper()

                # Draw circular piece badge
                badge_color = (250, 250, 250) if is_w else (35, 35, 35)
                border_color = (20, 20, 20) if is_w else (210, 210, 210)
                pygame.draw.circle(screen, badge_color, (cx, cy), SQ_SIZE // 2 - 8)
                pygame.draw.circle(screen, border_color, (cx, cy), SQ_SIZE // 2 - 8, 2)

                # Short letter code (K, Q, R, B, N, P)
                text_color = (20, 20, 20) if is_w else (245, 245, 245)
                surf = font_piece.render(p.upper(), True, text_color)
                screen.blit(surf, surf.get_rect(center=(cx, cy)))

def draw_hud():
    pygame.draw.rect(screen, (24, 26, 30), (0, BOARD_SIZE, WIDTH, HUD_HEIGHT))
    if not winner:
        msg = f"{'White' if current_turn == 'W' else 'Black'}'s Turn: Clear path home!"
        surf = font_hud.render(msg, True, (255, 215, 0))
    else:
        surf = font_win.render(f"{winner} King Reached Home!", True, (100, 230, 130))
    screen.blit(surf, surf.get_rect(center=(WIDTH // 2, BOARD_SIZE + HUD_HEIGHT // 2)))

async def main():
    global current_turn, selected_square, winner
    clock = pygame.time.Clock()
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and not winner:
                mx, my = pygame.mouse.get_pos()
                if my < BOARD_SIZE:
                    c = mx // SQ_SIZE
                    r = my // SQ_SIZE
                    if selected_square is None:
                        p = board[r][c]
                        if p != "." and ((current_turn == "W" and p.isupper()) or (current_turn == "B" and p.islower())):
                            selected_square = (r, c)
                    else:
                        sr, sc = selected_square
                        target = board[r][c]
                        # Move to adjacent open space
                        if target == "." and max(abs(r - sr), abs(c - sc)) == 1:
                            board[r][c] = board[sr][sc]
                            board[sr][sc] = "."
                            selected_square = None
                            
                            # Check Win condition
                            if board[7][4] == "K":
                                winner = "White"
                            elif board[0][4] == "k":
                                winner = "Black"
                            else:
                                current_turn = "B" if current_turn == "W" else "W"
                        else:
                            selected_square = (r, c) if (target != "." and ((current_turn == "W" and target.isupper()) or (current_turn == "B" and target.islower()))) else None

        draw_board()
        draw_pieces()
        draw_hud()
        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)

    pygame.quit()
    sys.exit()

asyncio.run(main())