import pygame
import sys
import asyncio

pygame.init()

BOARD_SIZE = 480
HUD_HEIGHT = 80
WIDTH = 480
HEIGHT = BOARD_SIZE + HUD_HEIGHT

ROWS, COLS = 8, 8
SQ_SIZE = BOARD_SIZE // COLS

LIGHT_SQ = (235, 236, 208)
DARK_SQ = (119, 149, 86)
HIGHLIGHT = (245, 230, 90)
TARGET_TILE_W = (180, 220, 240)
TARGET_TILE_B = (240, 190, 190)

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Race the King Home")

font_piece = pygame.font.SysFont("segoeuisymbol", 38)
font_hud = pygame.font.SysFont("Arial", 16, bold=True)
font_win = pygame.font.SysFont("Arial", 24, bold=True)

UNICODE_PIECES = {
    "K": "♔", "Q": "♕", "R": "♖", "B": "♗", "N": "♘", "P": "♙",
    "k": "♚", "q": "♛", "r": "♜", "b": "♝", "n": "♞", "p": "♟",
}

# The jammed initial board: Kings are stuck in rows 3 & 4
board = [
    [".", ".", ".", ".", ".", ".", ".", "."],  # Row 0, Col 4 is Black King's Home Throne
    [".", "r", "n", "b", "q", "b", "n", "r"],
    [".", "p", "p", "p", "p", "p", "p", "."],
    [".", ".", ".", ".", "k", ".", ".", "."],  # Black King stuck here
    [".", ".", ".", ".", "K", ".", ".", "."],  # White King stuck here
    [".", "P", "P", "P", "P", "P", "P", "."],
    [".", "R", "N", "B", "Q", "B", "N", "R"],
    [".", ".", ".", ".", ".", ".", ".", "."],  # Row 7, Col 4 is White King's Home Throne
]

current_turn = "W"
selected_square = None
winner = None

def draw_board():
    for r in range(ROWS):
        for c in range(COLS):
            rect = pygame.Rect(c * SQ_SIZE, r * SQ_SIZE, SQ_SIZE, SQ_SIZE)
            if (r, c) == (0, 4):
                color = TARGET_TILE_B
            elif (r, c) == (7, 4):
                color = TARGET_TILE_W
            else:
                color = LIGHT_SQ if (r + c) % 2 == 0 else DARK_SQ
            
            pygame.draw.rect(screen, color, rect)
            if selected_square == (r, c):
                pygame.draw.rect(screen, HIGHLIGHT, rect)

def draw_pieces():
    for r in range(ROWS):
        for c in range(COLS):
            p = board[r][c]
            if p != ".":
                cx = c * SQ_SIZE + SQ_SIZE // 2
                cy = r * SQ_SIZE + SQ_SIZE // 2
                symbol = UNICODE_PIECES.get(p, p)
                is_w = p.isupper()
                color = (255, 255, 255) if is_w else (20, 20, 20)
                
                if is_w:
                    shadow = font_piece.render(symbol, True, (40, 40, 40))
                    screen.blit(shadow, shadow.get_rect(center=(cx + 1, cy + 1)))
                
                surf = font_piece.render(symbol, True, color)
                screen.blit(surf, surf.get_rect(center=(cx, cy)))

def draw_hud():
    pygame.draw.rect(screen, (24, 26, 30), (0, BOARD_SIZE, WIDTH, HUD_HEIGHT))
    if not winner:
        msg = f"{'White' if current_turn == 'W' else 'Black'}'s Turn: Clear a path home!"
        surf = font_hud.render(msg, True, (255, 215, 0))
    else:
        surf = font_win.render(f"{winner} King Reached Home First!", True, (100, 230, 130))
    screen.blit(surf, surf.get_rect(center=(WIDTH // 2, BOARD_SIZE + HUD_HEIGHT // 2)))

async def main():
    global current_turn, selected_square, winner
    clock = pygame.time.Clock()
    running = True

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and not winner:
                mx, my = pygame.mouse.get_pos()
                if my < BOARD_SIZE:
                    c = mx // SQ_SIZE
                    r = my // SQ_SIZE
                    if selected_square is None:
                        p = board[r][c]
                        if p != "." and ((current_turn == "W" and p.isupper()) or (current_turn == "B" and p.islower())):
                            selected_square = (r, c)
                    else:
                        sr, sc = selected_square
                        target = board[r][c]
                        # Move to adjacent open space
                        if target == "." and max(abs(r - sr), abs(c - sc)) == 1:
                            board[r][c] = board[sr][sc]
                            board[sr][sc] = "."
                            selected_square = None
                            
                            # Check Win condition
                            if board[7][4] == "K":
                                winner = "White"
                            elif board[0][4] == "k":
                                winner = "Black"
                            else:
                                current_turn = "B" if current_turn == "W" else "W"
                        else:
                            selected_square = (r, c) if (target != "." and ((current_turn == "W" and target.isupper()) or (current_turn == "B" and target.islower()))) else None

        draw_board()
        draw_pieces()
        draw_hud()
        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)  # Required by Pygbag to allow the browser to breathe

    pygame.quit()
    sys.exit()

asyncio.run(main())